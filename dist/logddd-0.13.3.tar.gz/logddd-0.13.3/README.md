 # logddd
 Python 打印日志的方法，简单实现
 you can use it by  pip install logddd
